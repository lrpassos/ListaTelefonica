/*jshint browser:true */
/*global $ */(function()
{
 "use strict";
 /*
   hook up event handlers 
 */
 function register_event_handlers()
 {
    
    
     /* button  #btn_fones */
    $(document).on("click", "#btn_fones", function(evt)
    {
         /*global activate_page */
         activate_page("#Page_fones"); 
         return false;
    });
    
        /* button  #bnt_voltar_tel */
    $(document).on("click", "#bnt_voltar_tel", function(evt)
    {
         /*global activate_page */
         activate_page("#mainpage"); 
         return false;
    });
    
        /* button  #btn_sair */
    $(document).on("click", "#btn_sair", function(evt)
    {
       navigator.app.exitApp();
         return false;
    });
    
        /* listitem  #list_farmacia */
    
    
        /* button  #btn_voltar_utl */
    
    
        /* graphic button  #btn_farmacia_te */
    $(document).on("click", "#btn_farmacia_te", function(evt)
    {
        /* your code goes here */
        window.open('tel:7536211054','_system');
         return false;
    });
    
        /* listitem  #click_util */
    $(document).on("click", "#click_util", function(evt)
    {
         /*global activate_page */
         activate_page("#Page_uteis"); 
         return false;
    });
    
        /* button  #btn_voltar_utl */
    $(document).on("click", "#btn_voltar_utl", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#page_65_22"); 
         return false;
    });
    
        /* graphic button  #btn_policia */
    $(document).on("click", "#btn_policia", function(evt)
    {
        /* your code goes here */ 
        window.open('tel:190','_system');
         return false;
    });
    
        /* graphic button  SAMU */
    $(document).on("click", ".uib_w_21", function(evt)
    {
        /* your code goes here */ 
        window.open('tel:192','_system');
         return false;
    });
    
        /* graphic button  #btn_bombeiro */
    $(document).on("click", "#btn_bombeiro", function(evt)
    {
        /* your code goes here */ 
        window.open('tel:193','_system');
         return false;
    });
    
        /* graphic button  #btn_img_voltar */
    $(document).on("click", "#btn_img_voltar", function(evt)
    {
         /*global activate_page */
         activate_page("#mainpage"); 
         return false;
    });
    
        /* graphic button  #bnt_voltar2 */
    $(document).on("click", "#bnt_voltar2", function(evt)
    {
         /*global activate_page */
         activate_page("#mainpage"); 
         return false;
    });
    
        /* graphic button  #btn_civil */
    $(document).on("click", "#btn_civil", function(evt)
    {
        /* your code goes here */
        window.open('tel:7536213443','_system');
         return false;
    });
    
        /* graphic button  #bnt_voltar2_utltl */
    $(document).on("click", "#bnt_voltar2_utltl", function(evt)
    {
         /*global activate_page */
         activate_page("#Page_fones"); 
         return false;
    });
    
        /* graphic button  #btn_voltarutl */
    $(document).on("click", "#btn_voltarutl", function(evt)
    {
         /*global activate_page */
         activate_page("#Page_fones"); 
         return false;
    });
    
        /* listitem  #list_farmacia */
    $(document).on("click", "#list_farmacia", function(evt)
    {
         /*global activate_page */
         activate_page("#page_num_famacia"); 
         return false;
    });
    
        /* graphic button  #bnt_voltar_farm */
    $(document).on("click", "#bnt_voltar_farm", function(evt)
    {
         /*global activate_page */
         activate_page("#Page_fones"); 
         return false;
    });
    
        /* graphic button  #btn_far_cast_alves */
    $(document).on("click", "#btn_far_cast_alves", function(evt)
    {
        /* your code goes here */
         window.open('tel:7536211840','_system');
         return false;
    });
    
        /* button  #btn_sobre */
    $(document).on("click", "#btn_sobre", function(evt)
    {
         /*global activate_page */
         activate_page("#page_sobre"); 
         return false;
    });
    
        /* button  #btn_contato */
    $(document).on("click", "#btn_contato", function(evt)
    {
         /*global activate_page */
         activate_page("#page_contato"); 
         return false;
    });
    
        /* graphic button  #bnt_volta_cont */
    $(document).on("click", "#bnt_volta_cont", function(evt)
    {
         /*global activate_page */
         activate_page("#page_sobre"); 
         return false;
    });
    
        /* graphic button  #btn_voltar_sobre */
    $(document).on("click", "#btn_voltar_sobre", function(evt)
    {
         /*global activate_page */
         activate_page("#mainpage"); 
         return false;
    });
    
        /* graphic button  #bnt_img_capa */
    $(document).on("click", "#bnt_img_capa", function(evt)
    {
         /*global activate_page */
         activate_page("#Page_fones"); 
         return false;
    });
    
        /* graphic button  #bnt_bsaude */
    $(document).on("click", "#bnt_bsaude", function(evt)
    {
        /* your code goes here */
         window.open('tel:7536212445','_system');
         return false;
    });
    
        /* graphic button  #bnt_andrade */
    $(document).on("click", "#bnt_andrade", function(evt)
    {
        /* your code goes here */ 
        window.open('tel:7536212892','_system');
         return false;
    });
    
        /* graphic button  #bnt_calmas */
    $(document).on("click", "#bnt_calmas", function(evt)
    {
        /* your code goes here */
        window.open('tel:7536212491','_system');
         return false;
    });
    
        /* graphic button  #bnt_barreto */
    $(document).on("click", "#bnt_barreto", function(evt)
    {
        /* your code goes here */
        window.open('tel:7536211396','_system');
         return false;
    });
    
        /* graphic button  #btn_bairro */
    $(document).on("click", "#btn_bairro", function(evt)
    {
        /* your code goes here */ 
        window.open('tel:7536219887','_system');
         return false;
    });
    
        /* graphic button  #Btn_macsam */
    $(document).on("click", "#Btn_macsam", function(evt)
    {
        /* your code goes here */
        window.open('tel:7536212182','_system');
         return false;
    });
    
        /* graphic button  #btn_paguemenos */
    $(document).on("click", "#btn_paguemenos", function(evt)
    {
        /* your code goes here */
        window.open('tel:7536216702','_system');
         return false;
    });
    
        /* button  #btn_teste */
    
    
        /* button  #btn_teste */
    
    
        /* button  #btn_teste */
    
    
        /* button  #btn_teste */
    $(document).on("click", "#btn_teste", function(evt)
    {
         /*global activate_page */
         activate_page("#page_teste"); 
         return false;
    });
    
        /* listitem  #list_clinica */
    $(document).on("click", "#list_clinica", function(evt)
    {
         /*global activate_page */
         activate_page("#Page_clinica"); 
         return false;
    });
    
        /* graphic button  #btn_voltar_clini */
    $(document).on("click", "#btn_voltar_clini", function(evt)
    {
         /*global activate_page */
         activate_page("#Page_fones"); 
         return false;
    });
    
        /* graphic button  #btn_climil */
    $(document).on("click", "#btn_climil", function(evt)
    {
        /* your code goes here */
        window.open('tel:7533126036','_system');
         return false;
    });
    
        /* graphic button  #btn_uniclinica */
    $(document).on("click", "#btn_uniclinica", function(evt)
    {
        /* your code goes here */
        window.open('tel:7536212015','_system');
         return false;
    });
    
        /* graphic button  #btn_aliança */
    $(document).on("click", "#btn_aliança", function(evt)
    {
        /* your code goes here */
        window.open('tel:7536215552','_system');
         return false;
    });
    
        /* graphic button  #id_cemec */
    $(document).on("click", "#id_cemec", function(evt)
    {
        /* your code goes here */
        window.open('tel:7536211099','_system');
         return false;
    });
    
        /* graphic button  #bnt_rleite */
    $(document).on("click", "#bnt_rleite", function(evt)
    {
        /* your code goes here */ 
        window.open('tel:7536212234','_system');
         return false;
    });
    
        /* graphic button  #bnt_cardioimagem */
    $(document).on("click", "#bnt_cardioimagem", function(evt)
    {
        /* your code goes here */
        window.open('tel:753673-0000','_system');
         return false;
    });
    
        /* graphic button  #bnt_famede */
    $(document).on("click", "#bnt_famede", function(evt)
    {
        /* your code goes here */
        window.open('tel:753621148','_system');
         return false;
    });
    
        /* graphic button  #btn_svicente */
    $(document).on("click", "#btn_svicente", function(evt)
    {
        /* your code goes here */
        window.open('tel:7536211895','_system');
         return false;
    });
    
        /* graphic button  #bnt_saopaulo */
    $(document).on("click", "#bnt_saopaulo", function(evt)
    {
        /* your code goes here */
        window.open('tel:7536215266','_system');
         return false;
    });
    
        /* graphic button  #bnt_ces */
    $(document).on("click", "#bnt_ces", function(evt)
    {
        /* your code goes here */ 
        window.open('tel:7536215535','_system');
         return false;
    });
    
        /* graphic button  #btn_riobranco */
    $(document).on("click", "#btn_riobranco", function(evt)
    {
        /* your code goes here */
        window.open('tel:7536213437','_system');
         return false;
    });
    
        /* graphic button  #bnt_verdurao */
    $(document).on("click", "#bnt_verdurao", function(evt)
    {
        /* your code goes here */
        window.open('tel:7536216089','_system');
         return false;
    });
    
        /* listitem  #list_bnt_supermercado */
    $(document).on("click", "#list_bnt_supermercado", function(evt)
    {
         /*global activate_page */
         activate_page("#page_mercado"); 
         return false;
    });
    
        /* graphic button  #btn_voltar_super */
    
    
        /* graphic button  #btn_voltar_super */
    $(document).on("click", "#btn_voltar_super", function(evt)
    {
         /*global activate_page */
         activate_page("#Page_fones"); 
         return false;
    });
    
        /* graphic button  #Bnt_jpereira */
    $(document).on("click", "#Bnt_jpereira", function(evt)
    {
        /* your code goes here */
        window.open('tel:7536216315','_system');
         return false;
    });
    
        /* graphic button  #bnt_precobom */
    $(document).on("click", "#bnt_precobom", function(evt)
    {
        /* your code goes here */
        window.open('tel:7536211381','_system');
         return false;
    });
    
        /* graphic button  #btn_taxi */
    $(document).on("click", "#btn_taxi", function(evt)
    {
         /*global activate_page */
         activate_page("#Page_fones"); 
         return false;
    });
    
        /* listitem  #list_taxi */
    $(document).on("click", "#list_taxi", function(evt)
    {
         /*global activate_page */
         activate_page("#page_taxi"); 
         return false;
    });
    
        /* graphic button  #btn_volta_otica */
    $(document).on("click", "#btn_volta_otica", function(evt)
    {
         /*global activate_page */
         activate_page("#Page_fones"); 
         return false;
    });
    
        /* listitem  #list_oticas */
    $(document).on("click", "#list_oticas", function(evt)
    {
         /*global activate_page */
         activate_page("#page_otica"); 
         return false;
    });
    
        /* graphic button  #btn_volta_taxi */
    $(document).on("click", "#btn_volta_taxi", function(evt)
    {
         /*global activate_page */
         activate_page("#Page_fones"); 
         return false;
    });
    
    }
 document.addEventListener("app.Ready", register_event_handlers, false);
})();
